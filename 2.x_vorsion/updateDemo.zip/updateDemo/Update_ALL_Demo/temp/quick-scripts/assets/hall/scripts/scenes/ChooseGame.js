(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/hall/scripts/scenes/ChooseGame.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'a111cd8s6BPcL0u99YBbU7O', 'ChooseGame', __filename);
// hall/scripts/scenes/ChooseGame.js

'use strict';

cc.Class({
    extends: require('CustomScene'),

    properties: {},

    start: function start() {},

    onDestroy: function onDestroy() {
        this._super();
    },

    onLoad: function onLoad() {
        this._super();
    },

    onSetting: function onSetting() {
        PBHelper.addNode('DlgSetting');
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=ChooseGame.js.map
        