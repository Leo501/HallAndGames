(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/hall/scripts/helper/GameHelper.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'dda7coMMMJF/reILAe43VpG', 'GameHelper', __filename);
// hall/scripts/helper/GameHelper.js

'use strict';

/**
 * 
 * Game全局Helper
 * 
 */

/**
 * exports
 */
var helper = module.exports;

/**
 * initHelper
 */
helper.initHelper = function () {

    return helper;
};

helper.onLoadChooseScene = function (cb) {

    if (!cc.sys.isNative) {
        cc.director.loadScene('ChooseGame');
        return;
    }

    var gameName = UpdateHelper.gameType();
    var storagePath = UpdateHelper.genStoragePath(gameName);
    cc.log(storagePath);
    window.require(storagePath + "/src/dating.js");
    return;
};

helper.loadChooseScene = function (cb) {
    cc.director.loadScene('ChooseGame', function () {
        if (cb) cb();
    });
};

helper.loadGameScene = function (cb) {
    // web || package all
    if (!cc.sys.isNative) {

        switch (cc.currentGame) {

            case 'bjl':
                cc.director.loadScene('GameScene_BJL');
                break;
            case 'lkpy':
                cc.director.loadScene('GameScene_LKPY');
                break;
            case 'ddz':
                cc.director.loadScene('GameScene_DDZ');
                break;

        }
        return;
    }

    // native 
    UpdateHelper.init(cc.currentGame);
    var searchPaths = jsb.fileUtils.getSearchPaths();
    var storagePath = UpdateHelper.storagePath();
    cc.log("storagePath = ", storagePath);
    searchPaths.unshift(storagePath);
    jsb.fileUtils.setSearchPaths(searchPaths);
    helper.resortSearchPaths(cc.currentGame);
    window.require(storagePath + "/src/main.js");
};

helper.resortSearchPaths = function (topGameName) {
    var searchPaths = jsb.fileUtils.getSearchPaths();
    cc.log("[SearchPaths] 处理之前 = ", searchPaths);

    var newSearchPaths = [];

    var _iteratorNormalCompletion = true;
    var _didIteratorError = false;
    var _iteratorError = undefined;

    try {
        for (var _iterator = searchPaths[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
            var path = _step.value;

            if (path.indexOf(topGameName) > 0) {
                newSearchPaths.push(path);
                break;
            }
        }
        //这边为了解决一个bug , 把大厅的 路径塞进去 searchPaths[searchPaths.length - 3] 最好自己打印一下看看到底是第几个
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally {
        try {
            if (!_iteratorNormalCompletion && _iterator.return) {
                _iterator.return();
            }
        } finally {
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }

    newSearchPaths.push(searchPaths[searchPaths.length - 3]);
    jsb.fileUtils.setSearchPaths(newSearchPaths);

    cc.log("[SearchPaths] 处理之后 = ", newSearchPaths);
};

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=GameHelper.js.map
        