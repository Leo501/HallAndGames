(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/hall/scripts/scenes/LoadingScene.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'a1149+Q0xBBqalzd6Qdy1IQ', 'LoadingScene', __filename);
// hall/scripts/scenes/LoadingScene.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        ndLoading: cc.Node,
        ndUpdate: cc.Node,

        lbPer: cc.Label,

        lbUuid: cc.Label
    },

    onDestroy: function onDestroy() {},

    onLoad: function onLoad() {
        var _this = this;

        window.DataHelper = require('DataHelper').initHelper();

        // param
        this._loaded = 0;
        this._loadMax = 2;

        //预加载公共弹出框
        PBHelper.initHelper(function () {
            _this._onLoadDone();
        });

        this.checkHotUpdate();
    },

    checkHotUpdate: function checkHotUpdate() {
        cc.log('@checkhot');
        var com = this.getComponent('ComHotUpdate');
        com.check();
    },

    _onLoadDone: function _onLoadDone(id) {

        this._loaded++;
        cc.log(this._loaded);
        if (this._loaded >= this._loadMax) {
            this.onLoadAll();
            return;
        }
    },

    loadGame: function loadGame() {
        this._onLoadDone();
    },

    onLoadAll: function onLoadAll() {
        GameHelper.loadChooseScene();
    }

});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=LoadingScene.js.map
        