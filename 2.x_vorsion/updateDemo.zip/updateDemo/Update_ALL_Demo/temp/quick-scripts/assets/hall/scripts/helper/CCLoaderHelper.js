(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/hall/scripts/helper/CCLoaderHelper.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '466ffBi5YpBIrr7cmYM6ixL', 'CCLoaderHelper', __filename);
// hall/scripts/helper/CCLoaderHelper.js

"use strict";

/**
 * 
 * @param {*} path 
 * @param {*} type optional Only asset of type will be returned if this argument is supplied.
 * @param {*} cb (err,res)
 */
module.exports.getRes = function (path, type, cb) {
    var res = cc.loader.getRes(path);
    if (res == null) {
        cc.loader.loadRes(path, type, cb);
        return;
    }
    if (cb) cb();
};

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=CCLoaderHelper.js.map
        