(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/hall/scripts/views/Dlgs/DlgGameNeedDownload.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '89aadSywwRJu6Q5amht8nBK', 'DlgGameNeedDownload', __filename);
// hall/scripts/views/Dlgs/DlgGameNeedDownload.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad: function onLoad() {},


    initCb: function initCb(cb) {
        this._cb = cb;
    },

    onButtonClicked: function onButtonClicked(event, name) {
        switch (name) {
            case 'yes':
                if (this._cb) this._cb();
                this.node.removeFromParent();
                break;
            case 'cancel':
                this.node.removeFromParent();
                break;
        }
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=DlgGameNeedDownload.js.map
        