"use strict";
cc._RF.push(module, '045f372Zg9L45xNNpl12nr6', 'GameScene_LKPY');
// games/lkpy/scripts/GameScene_LKPY.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad: function onLoad() {},
    onExit: function onExit() {
        GameHelper.onLoadChooseScene();
    },
    onSetting: function onSetting() {
        //大厅的 prefab
        PBHelper.addNode('DlgSetting');
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();