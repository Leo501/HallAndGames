"use strict";
cc._RF.push(module, '215e4UYxN1BrY1WeTgEAJHu', 'CustomScene');
// hall/scripts/scenes/CustomScene.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad: function onLoad() {},

    onDisable: function onDisable() {},

    onDestroy: function onDestroy() {},

    start: function start() {}
});

cc._RF.pop();