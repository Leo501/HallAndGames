"use strict";
cc._RF.push(module, 'dff02aptohCWLo2LMjSYgHA', 'GameScene_DDZ');
// games/ddz/scripts/GameScene_DDZ.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad: function onLoad() {},
    onExit: function onExit() {
        GameHelper.onLoadChooseScene();
    },
    onSetting: function onSetting() {

        //大厅的 prefab

        PBHelper.addNode('DlgSetting');
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();