"use strict";
cc._RF.push(module, 'a111cd8s6BPcL0u99YBbU7O', 'ChooseGame');
// hall/scripts/scenes/ChooseGame.js

'use strict';

cc.Class({
    extends: require('CustomScene'),

    properties: {},

    start: function start() {},

    onDestroy: function onDestroy() {
        this._super();
    },

    onLoad: function onLoad() {
        this._super();
    },

    onSetting: function onSetting() {
        PBHelper.addNode('DlgSetting');
    }
});

cc._RF.pop();