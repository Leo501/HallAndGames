"use strict";
cc._RF.push(module, 'a11edlh/6lIn6P3jFVqURrF', 'DlgSetting');
// hall/scripts/views/Dlgs/DlgSetting.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad: function onLoad() {},

    onCloseDlg: function onCloseDlg() {
        this.node.removeFromParent();
    }

});

cc._RF.pop();