"use strict";
cc._RF.push(module, 'a1149+Q0xBBqalzd6Qdy1IQ', 'LoadingScene');
// hall/scripts/scenes/LoadingScene.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        ndLoading: cc.Node,
        ndUpdate: cc.Node,

        lbPer: cc.Label,

        lbUuid: cc.Label
    },

    onDestroy: function onDestroy() {},

    onLoad: function onLoad() {
        var _this = this;

        window.DataHelper = require('DataHelper').initHelper();

        // param
        this._loaded = 0;
        this._loadMax = 2;

        //预加载公共弹出框
        PBHelper.initHelper(function () {
            _this._onLoadDone();
        });

        this.checkHotUpdate();
    },

    checkHotUpdate: function checkHotUpdate() {
        cc.log('@checkhot');
        var com = this.getComponent('ComHotUpdate');
        com.check();
    },

    _onLoadDone: function _onLoadDone(id) {

        this._loaded++;
        cc.log(this._loaded);
        if (this._loaded >= this._loadMax) {
            this.onLoadAll();
            return;
        }
    },

    loadGame: function loadGame() {
        this._onLoadDone();
    },

    onLoadAll: function onLoadAll() {
        GameHelper.loadChooseScene();
    }

});

cc._RF.pop();