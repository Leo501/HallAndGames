"use strict";
cc._RF.push(module, '89aadSywwRJu6Q5amht8nBK', 'DlgGameNeedDownload');
// hall/scripts/views/Dlgs/DlgGameNeedDownload.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad: function onLoad() {},


    initCb: function initCb(cb) {
        this._cb = cb;
    },

    onButtonClicked: function onButtonClicked(event, name) {
        switch (name) {
            case 'yes':
                if (this._cb) this._cb();
                this.node.removeFromParent();
                break;
            case 'cancel':
                this.node.removeFromParent();
                break;
        }
    }
});

cc._RF.pop();