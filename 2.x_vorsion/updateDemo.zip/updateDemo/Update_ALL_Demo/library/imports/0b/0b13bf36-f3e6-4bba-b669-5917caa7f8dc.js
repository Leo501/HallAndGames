"use strict";
cc._RF.push(module, '0b13b828+ZLurZpWRfKp/jc', 'ComChooseGameState');
// hall/scripts/scenes/coms/ComChooseGameState.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad: function onLoad() {
        this.ndStateDown = cc.find('ndStateDown', this.node);
        this.ndDownload = cc.find('ndDownload', this.node); // downloading
        this.pbBar = cc.find('ndBar', this.ndDownload).getComponent(cc.ProgressBar);
    },


    initState: function initState(state) {},

    showCouldDownload: function showCouldDownload(show) {
        this.ndStateDown.active = show;
    },


    // num : 0 - 1 
    showDownloading: function showDownloading(show, num) {
        this.ndDownload.active = show;
        if (show) {
            this.pbBar.progress = num;
        }
    }
});

cc._RF.pop();