"use strict";
cc._RF.push(module, '466ffBi5YpBIrr7cmYM6ixL', 'CCLoaderHelper');
// hall/scripts/helper/CCLoaderHelper.js

"use strict";

/**
 * 
 * @param {*} path 
 * @param {*} type optional Only asset of type will be returned if this argument is supplied.
 * @param {*} cb (err,res)
 */
module.exports.getRes = function (path, type, cb) {
    var res = cc.loader.getRes(path);
    if (res == null) {
        cc.loader.loadRes(path, type, cb);
        return;
    }
    if (cb) cb();
};

cc._RF.pop();