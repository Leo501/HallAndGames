

cc.Class({
    extends: cc.Component,

    properties: {
       
    },

   

    onLoad () {},


    onExit () {
        GameHelper.onLoadChooseScene();
    },

    onSetting () {
        //大厅的 prefab
        PBHelper.addNode('DlgSetting');

    },


    start () {

    },

    // update (dt) {},
});
