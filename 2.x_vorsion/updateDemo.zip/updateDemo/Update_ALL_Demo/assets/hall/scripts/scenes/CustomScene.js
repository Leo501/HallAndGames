

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad: function () {

    },
    
    onDisable : function(){
    },

    onDestroy : function(){
        
    },
    
    start : function () {
      
    },
});
