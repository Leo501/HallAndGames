cc.Class({
    extends: cc.Component,

    properties: {
      
    },

    onLoad: function () {
       
    },

   

    onCloseDlg: function () {
        this.node.removeFromParent();
    },


});
